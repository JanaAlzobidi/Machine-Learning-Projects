# Results

Every algorithm saves its cluster labels here, **in the row order of `data/processed/customer_pca.csv`** (4,143 customers), so the final comparison can read them side by side.

| file | from | status |
|---|---|---|
| `labels_kmeans.npy` | `kmeans/` | pending |
| `labels_dbscan.npy` | `dbscan/` (noise = `-1`) | pending |
| `labels_hierarchical.npy` | `hierarchical/` | pending |
| `labels_gmm.npy` | `gmm/` | ✓ |
| `proba_gmm.npy` | `gmm/`: probability of every cluster per customer | ✓ |
| `gmm_segments.csv` | `gmm/`: cluster, segment name, probabilities, certainty per `CustomerID` | ✓ |
| `gmm_recommendations.csv` | `gmm/`: three suggested products per customer | ✓ |

Quick check that a labels file has the right shape:
```python
import numpy as np, pandas as pd
Z = pd.read_csv("../data/processed/customer_pca.csv", index_col="CustomerID")
labels = np.load("labels_kmeans.npy")
assert len(labels) == len(Z)
```
