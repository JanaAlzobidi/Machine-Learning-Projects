# Customer Segmentation: Comparing Four Clustering Algorithms

We segment the customers of a UK online gift retailer with **K-Means, DBSCAN, Hierarchical clustering and Gaussian Mixture Models**, all run on exactly the same prepared data, and then compare how each algorithm behaves.

| Algorithm | Folder | Owner | Status |
|---|---|---|---|
| K-Means | [`kmeans/`](kmeans/) | _name_ | in progress |
| DBSCAN | [`dbscan/`](dbscan/) | _name_ | in progress |
| Hierarchical | [`hierarchical/`](hierarchical/) | _name_ | in progress |
| Gaussian Mixture Model | [`gmm/`](gmm/) | _name_ | done |

## Repository structure
```
customer-segmentation-clustering/
├── 01_data_preparation.ipynb     shared cleaning, features, transform and PCA
├── data/
│   ├── raw/data.csv.gz           raw transactions (gzip, 7.5 MB)
│   └── processed/                the files every algorithm uses (see below)
├── kmeans/README.md              instructions for the K-Means notebook
├── dbscan/README.md              instructions for the DBSCAN notebook
├── hierarchical/README.md        instructions for the Hierarchical notebook
├── gmm/                          GMM notebook + README
├── results/                      every algorithm saves its cluster labels here
└── requirements.txt
```
All data lives in `data/`. The algorithm folders contain only instructions and notebooks, never copies of the data.

## Quick start
```bash
git clone https://github.com/<your-username>/customer-segmentation-clustering.git
cd customer-segmentation-clustering
pip install -r requirements.txt
```
Then open the README in your algorithm's folder. The processed data is already in the repository, so you do **not** need to rerun `01_data_preparation.ipynb` unless you change the preparation.

**Google Colab:** read the files straight from GitHub instead of a local path (the repository must be public):
```python
BASE = "https://raw.githubusercontent.com/<your-username>/customer-segmentation-clustering/main/data/processed/"
```

## Data
Online Retail transactions of a UK online retailer, 01/12/2010 to 09/12/2011 (541,909 invoice lines), as used in the Kaggle notebook [Customer Segmentation & Recommendation System](https://www.kaggle.com/code/farzadnekouei/customer-segmentation-recommendation-system). The original source is the [UCI Machine Learning Repository](https://archive.ics.uci.edu/dataset/352/online+retail) (Chen, Sain & Guo, 2012).

`01_data_preparation.ipynb` cleans the lines, builds 12 features per customer, sets aside the 5% most extreme customers (Isolation Forest), applies a Yeo-Johnson transform and reduces the features to 5 PCA components (89% of the variance).

### Processed files (`data/processed/`)
| file | rows x cols | what it is | used by |
|---|---|---|---|
| `customer_pca.csv` | 4,143 x 5 | **main clustering input**: 5 PCA components of the regular customers | everyone |
| `customer_features.csv` | 4,362 x 14 | 12 readable features + `Country` + `IsOutlier`, all customers | everyone, to describe clusters |
| `customer_pca_all.csv` | 4,362 x 6 | the same 5 components **including** the 219 set-aside customers, + `IsOutlier`; regular customers have exactly the values in `customer_pca.csv` | noise tests (DBSCAN, GMM) |
| `customer_features_transformed.csv` | 4,143 x 12 | the 12 features after Yeo-Johnson, before PCA | optional experiment |

All files are indexed by `CustomerID`, with the regular customers in the same order everywhere.

## Rules for a fair comparison
1. Everyone clusters `data/processed/customer_pca.csv` **without rescaling it**.
2. Everyone describes clusters with `customer_features.csv` (readable features, not PCs).
3. Everyone saves `results/labels_<algorithm>.npy` in the row order of `customer_pca.csv` (DBSCAN noise = `-1`).
4. Everyone reports the same things: number of clusters, cluster sizes, silhouette, Davies-Bouldin, a PC1/PC2 plot, sensitivity to noise, strengths and weaknesses.
5. `random_state=42` wherever there is randomness.

## Results so far
**GMM** (4 components, full covariance, silhouette 0.31): one-time buyers (31% of customers, 9% of spend), steady repeat buyers (32%, 29%), big baskets slowing down (9%, 14%), frequent buyers who return items (29%, 48%). Details in [`gmm/`](gmm/).

## Requirements
Python 3.10+. Tested with pandas 2.2 and 3.0, scikit-learn 1.5 and 1.9.

## Acknowledgement
The preparation pipeline is adapted from Farzad Nekouee's Kaggle notebook linked above; every change is explained inside `01_data_preparation.ipynb`.
